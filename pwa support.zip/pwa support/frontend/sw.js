// GeoAttend Service Worker v1.3
const CACHE_NAME = 'geoattend-v3';
const ASSETS = [
    '/',
    '/index.html',
    '/admin123.html',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'
];

// ── Install ──────────────────────────────────────────────────
self.addEventListener('install', event => {
    // Force this new version to activate immediately
    self.skipWaiting();
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)).catch(() => {})
    );
});

// ── Activate ─────────────────────────────────────────────────
self.addEventListener('activate', event => {
    // Take control of ALL open tabs immediately
    event.waitUntil(
        caches.keys().then(keys =>
            Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
        ).then(() => self.clients.claim())
    );
});

// ── Fetch ────────────────────────────────────────────────────
self.addEventListener('fetch', event => {
    if (event.request.method !== 'GET') return;
    if (event.request.url.includes('/api/')) return;

    event.respondWith(
        caches.match(event.request).then(cached => {
            const network = fetch(event.request).then(response => {
                if (response && response.status === 200 && response.type === 'basic') {
                    const clone = response.clone();
                    caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
                }
                return response;
            }).catch(() => cached);
            return cached || network;
        })
    );
});

// ── Push: show notification ───────────────────────────────────
self.addEventListener('push', event => {
    let data = {};
    try {
        data = event.data ? event.data.json() : {};
    } catch (e) {
        data = { title: 'GeoAttend', body: 'Attendance session started!' };
    }

    const title = data.title || 'GeoAttend Attendance';
    const options = {
        body: data.body || 'A new attendance session has started.',
        icon: '/icon-192.png',
        badge: '/icon-96.png',
        tag: 'geoattend-session',
        renotify: true,
        requireInteraction: true,
        vibrate: [200, 100, 200],
        data: {
            url: data.url || '/'
        },
        actions: [
            { action: 'verify', title: '✅ Verify Attendance' },
            { action: 'dismiss', title: '❌ Dismiss' }
        ]
    };

    event.waitUntil(self.registration.showNotification(title, options));
});

// ── Notification Click ────────────────────────────────────────
self.addEventListener('notificationclick', event => {

    // ❌ DISMISS — just close, do nothing else
    if (event.action === 'dismiss') {
        event.notification.close();
        return;
    }

    // ✅ VERIFY or tapping notification body — open the app
    event.notification.close();

    const targetUrl = event.notification.data.url || '/';

    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then(windowClients => {
            for (const client of windowClients) {
                if ('focus' in client) {
                    client.focus();
                    return;
                }
            }
            return clients.openWindow(targetUrl);
        })
    );
});